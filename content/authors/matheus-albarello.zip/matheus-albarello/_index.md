---
# Display name
name: Matheus Albarello

# Username (this should match the folder name)
authors:
- matheus-albarello

# Is this the primary user of the site?
superuser: false

# Role/position
role: UFRGS MSc 2019-... (part-time)

# Organizations/Affiliations
organizations:
- name: "INF/UFRGS, Sicredi"
  url: "https://br.linkedin.com/in/malbarello/"

# Short bio (displayed in user profile at end of posts)
#bio: My research interests include computer networks and cybersecurity.

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
#- Principal Investigators
#- Researchers
- Master Students
#- Visitors

---
